import logging

class dplogger:

    __LVL_PASS = 0
    __LVL_DEBUG = 1
    __LVL_INFO = 2
    __LVL_WARNING = 3
    __LVL_ERROR = 4
    __LVL_CRITICAL = 5

    itemList = []

    def __init__(self, logger: logging):
        self.logger = logger

    def dispatch(self):
        dispatchList = self.itemList.copy()
#        print(str(len(dispatchList)))
        self.itemList.clear()

        for item in dispatchList:
            if(item['lvl'] == self.__LVL_DEBUG):
                self.logger.debug(item['msg'])#, item['args'], item['kwargs'])
            elif(item['lvl'] == self.__LVL_INFO):
                self.logger.info(item['msg'])#, item['args'], item['kwargs'])
            elif(item['lvl'] == self.__LVL_WARNING):
                self.logger.warning(item['msg'])#, item['args'], item['kwargs'])
            elif(item['lvl'] == self.__LVL_ERROR):
                self.logger.error(item['msg'])#, item['args'], item['kwargs'])
            elif(item['lvl'] == self.__LVL_CRITICAL):
                self.logger.critical(item['msg'])#, item['args'], item['kwargs'])
            elif(item['lvl'] == self.__LVL_PASS):
                self.logger.log(item['pass'], item['msg'])#, item['args'], item['kwargs'])

    def debug(self, msg, *args, **kwargs):
        item = {'lvl': self.__LVL_DEBUG, 'msg': msg}#, 'args': args, 'kwargs': kwargs}
        self.itemList.append(item)

    def info(self, msg, *args, **kwargs):
        item = {'lvl': self.__LVL_INFO, 'msg': msg}#, 'args': args, 'kwargs': kwargs}
        self.itemList.append(item)

    def warning(self, msg, *args, **kwargs):
        item = {'lvl': self.__LVL_WARNING, 'msg': msg}#, 'args': args, 'kwargs': kwargs}
        self.itemList.append(item)

    def error(self, msg, *args, **kwargs):
        item = {'lvl': self.__LVL_ERROR, 'msg': msg}#, 'args': args, 'kwargs': kwargs}
        self.itemList.append(item)

    def critical(self, msg, *args, **kwargs):
        item = {'lvl': self.__LVL_CRITICAL, 'msg': msg}#, 'args': args, 'kwargs': kwargs}
        self.itemList.append(item)

    def log(self, level, msg, *args, **kwargs):
        #item = {'lvl': self.__LVL_PASS, 'msg': msg, 'args': args, 'kwargs': kwargs, 'pass': level}
        item = {'lvl': self.__LVL_PASS, 'msg': msg, 'pass': level}
        self.itemList.append(item)

