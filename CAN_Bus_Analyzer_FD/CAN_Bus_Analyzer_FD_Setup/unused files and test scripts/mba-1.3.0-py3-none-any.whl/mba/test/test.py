"""

"""

################################################################################
import argparse
import logging
import queue
import sys
import threading
import time
import secrets

################################################################################
import mba
#import mba.test.dispatchlogger as dplogger
from mba.test.dispatchlogger import dplogger

################################################################################
_SEPARATOR = '################################################################################'

PASS = 0
FAIL = 1

_LOGGING_LEVELS = ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL', 'NONE')
_LOGGING_LEVEL_MAP = {'DEBUG': 10, 'INFO': 20, 'WARNING': 30, 'ERROR': 40, 'CRITICAL': 50, 'NONE': 100}

GENERATOR_MAX_QUEUE_SIZE = 20

if False:
    logging.debug = print
    logging.info = print
    logging.error = print

################################################################################
class PacketGenerator(object):

    def __init__(self, packet_size, extended_id=False):
        """

        :param bus_id:
        :param packet_size: Must be 2 or greater
        """
        super(PacketGenerator, self).__init__()

        self.packet_size = packet_size
        self.extended_id = extended_id

        self._priority_id = 0
        #self._priority_id = secrets.randbits(7)
        self._datum = 0
        self._uid = 0

        self._q = queue.Queue(maxsize=GENERATOR_MAX_QUEUE_SIZE)
        # Prefill the q
        for i in range(GENERATOR_MAX_QUEUE_SIZE):
            self._generate()

        self._fill_thread = threading.Thread(target=self._fill_thread_func, daemon=True)
        self._fill_thread.start()

    def _fill_thread_func(self):
        while True:
            self._generate()

    def _generate(self):
        self._priority_id += 1
        if self.extended_id:
            self._priority_id &= 0b11111111111111111111111111111
        else:
            self._priority_id &= 0b11111111111

        # First two bytes are the uid
        data = [(self._uid >> 8) & 0xFF, self._uid & 0xFF]
        self._uid += 1
        self._uid &= 0xFFFF

        for i in range(self.packet_size-2):
            data.append(self._datum)
            self._datum += 1
            self._datum &= 0xFF

        while True:
            ok = False
            try:
                self._q.put((self._priority_id, data), timeout=0.05)
                ok = True
            except queue.Full:
                pass
            except:
                logging.error('Failed call to generator call to q.put.')
                raise

            if ok:
                break

    def get_packet(self):
        packet = self._q.get(timeout=0.5)
        return packet


################################################################################
class ThreadParams(object):
    _lock = threading.Lock()

    def __init__(self, args=None, serial_num=0, q=None, loop_num=0):
        self.args = args
        self.serial_num = serial_num
        self.q = q
        self.loop_num = loop_num

        self.extended_id = False
        self.flags = 0
        if 'extended' in args.flags:
            self.flags |= mba.CANFRAME_FLAG_EXTENDED
            self.extended_id = True

        if 'fd' in args.flags:
            self.flags |= mba.CANFRAME_FLAG_FD

        if 'brs' in args.flags:
            self.flags |= mba.CANFRAME_FLAG_BRS

        self.pg = PacketGenerator(args.num_payload_bytes, self.extended_id)

        self.stop = False
        self.instance = None

        self.num_loops = args.num_loops
        self.num_tx = args.num_tx
        self.num_payload_bytes = args.num_payload_bytes
        self.flags = args.flags

        self.can_auto_retry = args.auto_retry
        self.can_bus_ids = args.bus_ids
        self.can_data_speed = args.data_speed
        self.can_mode = args.mode
        self.can_nominal_speed = args.nominal_speed
        self.can_timeout = args.timeout
        self.can_test_mode = args.test_mode

        self.num_devices = len(self.can_bus_ids)

        self.error_count = 0
        self.general_error_count = 0
        self.rx_error_counts = {i: 0 for i in self.can_bus_ids}

        # 1 for get_version
        # 1 for each can_set_mode per bus tested
        # 1 for each can_set_speed per bus tested
        # 2 for each each tx per bus tested
        self.ok_count_expected = 1 \
                            + len(self.can_bus_ids)\
                            + len(self.can_bus_ids)\
                            + (2 * self.num_tx * len(self.can_bus_ids))
        self.ok_count = 0
        self.rx_ok_counts = {i: 0 for i in self.can_bus_ids}
        self.tx_ok_counts = {i: 0 for i in self.can_bus_ids}
        self.rx_get_version_ok_count = 0

        self.start_time = 0.0
        self.end_time = 0.0
        self.total_time = 0.0
        self.total_payload_bytes = 0
        self.payload_data_rate = 0.0

    def get_string(self):
        self._lock.acquire()
        s = 'Loop %s Results = \n' % self.loop_num
        s += '    serial_num                    = %s\n' % str(self.serial_num)
        s += '    instance                      = %s\n' % str(self.instance)
        s += '    auto_retry                    = %s\n' % str(self.can_auto_retry)
        s += '    data_speed                    = %s\n' % str(self.can_data_speed)
        s += '    num_payload_bytes             = %s\n' % str(self.num_payload_bytes)
        s += '    extended_id                   = %s\n' % str(self.extended_id)
        s += '    mode                          = %s\n' % str(self.can_mode)
        s += '    nominal_speed                 = %s\n' % str(self.can_nominal_speed)
        s += '    timeout                       = %s\n' % str(self.can_timeout)
        s += '    test_mode                     = %s\n' % str(self.can_test_mode)
        s += '    ok_count_expected             = %s\n' % str(self.ok_count_expected)
        s += '    ok_count                      = %s\n' % str(self.ok_count)
        s += '    rx_ok_counts (busId:value)    = %s\n' % str(self.rx_ok_counts)
        s += '    tx_ok_counts (busId:value)    = %s\n' % str(self.tx_ok_counts)
        s += '    rx_get_version_ok_count       = %s\n' % str(self.rx_get_version_ok_count)
        s += '    rx_error_counts (busId:value) = %s\n' % str(self.rx_error_counts)
        s += '    general_error_count           = %s\n' % str(self.general_error_count)
        s += '    error_count                   = %s\n' % str(self.error_count)
        s += '    start_time                    = %ss\n' % str(self.start_time)
        s += '    end_time                      = %ss\n' % str(self.end_time)
        s += '    total_time                    = %ss\n' % str(self.total_time)
        s += '    total_payload_bytes           = %s\n' % str(self.total_payload_bytes)
        s += '    payload_data_rate             = %skBs' % str(self.payload_data_rate)
        self._lock.release()
        return s

    def _inc_error_count(self):
        self.error_count += 1

    def _inc_general_error_count(self):
        self.general_error_count += 1
        self._inc_error_count()

    def _inc_ok_count(self):
        self.ok_count += 1

    def _inc_rx_error_count(self, bus_id):
        self.rx_error_counts[bus_id] += 1
        self._inc_error_count()

    def _inc_rx_get_version_ok_count(self):
        self.rx_get_version_ok_count += 1
        self._inc_ok_count()

    def _inc_rx_ok_count(self, bus_id):
        self.rx_ok_counts[bus_id] += 1
        self._inc_ok_count()

    def _inc_tx_ok_count(self, bus_id):
        self.tx_ok_counts[bus_id] += 1
        self._inc_ok_count()

    def inc_general_error_count(self):
        self._lock.acquire()
        self._inc_general_error_count()
        self._lock.release()

    def inc_rx_get_version_ok_count(self):
        self._lock.acquire()
        self._inc_rx_get_version_ok_count()
        self._lock.release()

    def inc_rx_error_count(self, bus_id):
        self._lock.acquire()
        self._inc_rx_error_count(bus_id)
        self._lock.release()

    def inc_rx_ok_count(self, bus_id):
        self._lock.acquire()
        self._inc_rx_ok_count(bus_id)
        self._lock.release()

    def inc_tx_ok_count(self, bus_id):
        self._lock.acquire()
        self._inc_tx_ok_count(bus_id)
        self._lock.release()

################################################################################
def _device_callback(data):
    """ Device driver callback function for data received from the CBA-FD. This
    code runs in the driver context and does not respond to breakpoints. So, to
    facilitate debug of the parsing code we put the data in a  queue and let the
     _mba_device_rx_thread handle the parsing.

    :param data: MbaCallbackData object
    """
    params = data.user_data

    try:
        params.q.put(data, timeout=2.0)
    except queue.Full:
        if params.args.debug:
            logging.error('Failed to enqueue data for device instance=%s.' % str(params.instance))


################################################################################
g_saved_rx_data = []
def _mba_device_rx_thread(params):
    global g_saved_rx_data

    instance = params.instance
    q = params.q
    serial_num = params.serial_num
    while True:
        if params.stop:
            break

        data = None
        try:
            data = q.get(block=True, timeout=0.05)
        except queue.Empty:
            pass

        if data is None:
            continue

        g_saved_rx_data.append(data)

        if data.instance != instance:
            if params.args.debug:
                s = 'Invalid data.instance=%s for this device instance %s.' % (str(instance), str(data.instance))
                logging.error(s)
            params.inc_general_error_count()
            continue

        if mba.TYPE_CAN == data.type:
            if mba.CAN_MSG_BITRATE == data.command:
                params.inc_rx_ok_count(data.msg.busId)
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            elif mba.CAN_MSG_DBG == data.command:
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            elif mba.CAN_MSG_ERR == data.command:
                params.inc_rx_error_count(data.msg.busId)
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.error(s)
            elif mba.CAN_MSG_MODE == data.command:
                params.inc_rx_ok_count(data.msg.busId)
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            elif (mba.CAN_MSG_RX == data.command) or (mba.CAN_MSG_TX == data.command):
                if mba.CAN_MSG_RX == data.dir:
                    params.inc_rx_ok_count(data.msg.busId)
                    direction = 'RX'
                else:
                    params.inc_tx_ok_count(data.msg.busId)
                    direction = 'TX'
                if params.args.debug:
                    s = 'sn=%s direction=%s:\n%s' % (str(serial_num), direction, data.msg.get_string('    '))
                    logging.debug(s)
            else:
                params.inc_general_error_count()
                if params.args.debug:
                    s = 'Invalid TYPE_CAN data.command=%s for instance=%s' % (str(data.type), str(instance))
                    logging.error(s)
        elif mba.TYPE_MBA == data.type:
            if mba.MBA_CMD_DEVICEDISCONNECTED == data.command:
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            if mba.MBA_CMD_DEVICERECONNECTED == data.command:
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            if mba.MBA_CMD_TIMESTAMP == data.command:
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            if mba.MBA_CMD_USBERROR == data.command:
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            elif mba.MBA_CMD_VERSION == data.command:
                params.inc_rx_get_version_ok_count()
                if params.args.debug:
                    s = 'sn=%s direction=RX:\n%s' % (str(serial_num), data.msg.get_string('    '))
                    logging.debug(s)
            else:
                params.inc_general_error_count()
                if params.args.debug:
                    s = 'Invalid TYPE_MBA data.command=%s for instance=%s' % (str(data.type), str(instance))
                    logging.error(s)
        else:
            params.inc_general_error_count()
            if params.args.debug:
                s = 'Invalid data.type=%s for instance=%s' % (str(data.type), str(instance))
                logging.error(s)

    logging.debug('%s _mba_device_rx_thread thread stopped.' % str(serial_num))


################################################################################
def _mba_device_thread(params):
    serial_num = params.serial_num

    logging.debug('sn=%s starting.' % str(serial_num))

    if 'classic' == params.can_mode.lower():
        mode = mba.CAN_MODE_CLASSIC
    elif 'fdniso' == params.can_mode.lower():
        mode = mba.CAN_MODE_FDNISO
    elif 'fd' == params.can_mode.lower():
        mode = mba.CAN_MODE_FD
    else:
        raise Exception('Invalid mode arg %s' % str(params.can_mode))

    if 'normal' == params.can_test_mode.lower():
        test_mode = mba.CAN_TESTMODE_NORMAL
    elif 'intloop' == params.can_test_mode.lower():
        test_mode = mba.CAN_TESTMODE_LOOPBACK
    elif 'extloop' == params.can_test_mode.lower():
        test_mode = mba.CAN_TESTMODE_EXTLOOPBACK
    else:
        raise Exception('Invalid test_mode arg %s' % str(params.can_test_mode))

    if params.can_auto_retry:
        auto_retry = 1
    else:
        auto_retry = 0

    device = mba.Mba()
    instance = device.open_device(serial_num)
    if 0 > instance:
        params.inc_general_error_count()
        logging.error('sn=%s failed to open device with error code %s' % (str(serial_num), str(instance)))
        return
    logging.debug('sn=%s device opened as instance %s' % (str(serial_num), str(instance)))

    rc = device.mba_reset(mba.MBA_RESET_APPLICATION)
    if mba.E_OK != rc:
        device.close_device()
        params.inc_general_error_count()
        logging.error('sn=%s failed to reset.' % str(serial_num))
        return

    device.close_device()

    if params.args.debug:
        logging.info('sn=%s waiting for device to reset & re-enumerate in the OS.' % str(serial_num))

    device = mba.Mba()
    timeout = time.time() + 5.0
    while True:
        instance = device.open_device(serial_num)
        if 0 <= instance:
            break

        if time.time() > timeout:
            params.inc_general_error_count()
            logging.error('sn=%s failed to open device after reset with error code %s' %
                           (str(serial_num), str(instance)))
            return

        time.sleep(0.05)

    logging.info('sn=%s device opened after reset as instance %s' % (str(serial_num), str(instance)))

    params.instance = instance
    rc = device.register_callback(_device_callback, params)
    if mba.E_OK != rc:
        device.close_device()
        params.inc_general_error_count()
        logging.error('sn=%s failed to register callback.' % str(serial_num))
        return

    rx_thread = threading.Thread(target=_mba_device_rx_thread, args=(params, ), daemon=True)
    rx_thread.start()

    device.mba_get_version()

    for bus_id in params.can_bus_ids:
        bus_id_string = 'CAN%s' % str(bus_id)
        rc = device.can_set_speed(bus_id, params.can_nominal_speed, params.can_data_speed)
        if mba.E_OK != rc:
            device.close_device()
            params.inc_general_error_count()
            logging.error('sn=%s failed to set %s speed with error %s.' % (str(serial_num), bus_id_string, str(rc)))
            return

    for bus_id in params.can_bus_ids:
        rc = device.can_set_mode(bus_id, mode, test_mode, auto_retry)
        if mba.E_OK != rc:
            device.close_device()
            params.inc_general_error_count()
            bus_id_string = 'CAN%s' % str(bus_id)
            logging.error('sn=%s failed to set %s mode with error %s.' % (str(serial_num), bus_id_string, str(rc)))
            return

    params.start_time = time.time()
    for i in range(params.num_tx):
        for bus_id in params.can_bus_ids:
            packet = params.pg.get_packet()
            logging.debug(str(packet[0]))
            rc = device.can_send_frame(
                bus_id,
                packet[0] + (bus_id * 0x100),
                packet[1],
                params.num_payload_bytes,
                mba.CANFRAME_FLAG_FD | mba.CANFRAME_FLAG_BRS,
                params.can_timeout)
            if mba.E_OK != rc:
                device.close_device()
                params.inc_general_error_count()
                bus_id_string = 'CAN%s' % str(bus_id)
                logging.error('sn=%s failed %s send frame %s with rc = %s' % (str(serial_num), bus_id_string, str(i), str(rc)))
                return
            params.total_payload_bytes += params.num_payload_bytes

    # Wait for all rx messages
    timeout = time.time() + 4.0
    while True:
        if params.ok_count_expected == params.ok_count:
            params.end_time = time.time()
            params.stop = True
            break

        if time.time() > timeout:
            params.end_time = time.time()
            params.inc_general_error_count()
            logging.error('sn=%s Timeout waiting for all rx messages' % str(serial_num))
            break

        time.sleep(0.05)

    device.close_device()

    params.stop = True

    params.total_time = params.end_time - params.start_time
    params.payload_data_rate = (params.total_payload_bytes / params.total_time) / 1000

    logging.info('sn=%s finished.' % str(serial_num))
    logging.debug('%s _mba_device_thread thread stopped.' % str(serial_num))


################################################################################
def create_args(args=None):
    parser = argparse.ArgumentParser()

    parser.add_argument('-a', '--auto_retry', dest='auto_retry',
                        default=True, required=False, action='store_true',
                        help='Enable HW retry. Default=True')

    parser.add_argument('-b', '--bus_ids', dest='bus_ids', nargs='*',
                        default=[0, 1], required=False, type=int,
                        help='CAN bus IDs to test. Default=0 1')

    parser.add_argument('-c', '--num_payload_bytes', dest='num_payload_bytes',
                        default=8, required=False, type=int,
                        help='Number of bytes for tx payload in the range 8 to 64. Default=8')

    parser.add_argument('-d', '--data_speed', dest='data_speed', choices=mba.CAN_DATA_SPEEDS,
                        default=2000, required=False, type=int,
                        help='CAN data speed. Default=2000')

    parser.add_argument('-f', '--flags', dest='flags', choices=['none', 'extended', 'fd', 'brs'],
                        default=['none'], required=False,
                        help='CAN send frame flags. Default=none')

    parser.add_argument('-j', '--num_loops', dest='num_loops', type=int,
                        default=1, required=False,
                        help='Number of main loop iterations. Default=1')

    parser.add_argument('-k', '--num_tx', dest='num_tx', type=int,
                        default=5, required=False,
                        help='Number of CAN frames to transmit per iteration. Default=5')

    parser.add_argument('-l', '--log_level', dest='log_level', choices=_LOGGING_LEVELS,
                        default='INFO', required=False,
                        help='Logging level. Default=INFO')

    parser.add_argument('-m', '--mode', dest='mode', choices=['classic', 'fdniso', 'fd'],
                        default='fd', required=False,
                        help='CAN mode. Default=fd')

    parser.add_argument('-n', '--nominal_speed', dest='nominal_speed', choices=mba.CAN_NOMINAL_SPEEDS,
                        default=1000, required=False, type=int,
                        help='CAN nominal speed. Default=1000')

    parser.add_argument('-o', '--timeout', dest='timeout',
                        default=1000, required=False, type=int,
                        help='CAN send frame timeout in seconds. Default=1000')

    parser.add_argument('-s', '--serial_num', dest='serial_num',
                        default=None, required=False,
                        help='Serial number of CBA-FD to test. Default=None, test all detected.')

    parser.add_argument('-t', '--test_mode', dest='test_mode', choices=['normal', 'intloop', 'extloop'],
                        default='normal', required=False,
                        help='CAN test mode. Default=normal')

    if args is None:
        args = parser.parse_args()
    else:
        args = parser.parse_args(args)

    if 'NONE' == args.log_level:
        args.debug = False
    else:
        args.debug = True

    return args


################################################################################
def test(arguments, _logger = None):
#def test(arguments):

    deferedLogger: dplogger = None

    if _logger is not None:
        deferedLogger = dplogger(_logger)
    else:
        deferedLogger = dplogger(logging.getLogger())

    logging.debug = deferedLogger.debug
    logging.info = deferedLogger.info
    logging.error = deferedLogger.error

    for i in range(arguments.num_loops):
        logging.info(_SEPARATOR)
        logging.info('Main loop = %s' % str(i))

        if arguments.serial_num is None:
            num_devices, types, serial_nums = mba.enum_devices()
            if 0 >= num_devices:
                raise Exception('No devices detected.')
        else:
            num_devices = 1
            serial_nums = [arguments.serial_num]

        device_threads = []
        thread_params = []
        for j in range(num_devices):
            params = ThreadParams(
                args=arguments,
                serial_num=serial_nums[j],
                q=queue.Queue(),
                loop_num=i)
            thread_params.append(params)
            device_threads.append(threading.Thread(target=_mba_device_thread, args=(params, ), daemon=True))

        for device_thread in device_threads:
            device_thread.start()

        for device_thread in device_threads:
            deferedLogger.dispatch()
            while(device_thread.is_alive()):
                device_thread.join(0.1)
                deferedLogger.dispatch()

        for params in thread_params:
            s = params.get_string()
            if params.args.debug:
                logging.info(s)
            else:
                print(s)
            if 0 < params.error_count:
                if params.args.debug:
                    logging.error('sn=%s detected %s error(s) for loop=%s' %
                                   (str(params.serial_num), str(params.error_count), str(i)))

    if 0 < params.error_count:
        s = 'TEST FAIL: %s total error(s) detected' % str(params.error_count)
        if params.args.debug:
            logging.error(s)
        else:
            print(s)
        rc = -1
    else:
        if params.args.debug:
            logging.info('TEST SUCCESS')
        else:
            print('TEST SUCCESS')
        rc = 0

    global g_saved_rx_data
    for datum in g_saved_rx_data:
        logging.debug(datum.get_string())

    return rc


################################################################################
if __name__ == '__main__':

    args = create_args()

    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logging.basicConfig(format=log_format, level=_LOGGING_LEVEL_MAP[args.log_level])

    try:
        result = test(args)
    except KeyboardInterrupt:
        result = 0

    sys.exit(result)
