# coding: utf-8

"""
Microchip Automotive Bus Analyzer  
Microchip CAN Bus Analyzer  
Copyright (C) 2019 Microchip Automotive GmbH & Co. KG
"""

################################################################################
import logging

################################################################################
# Import Standard Python Modules
import collections
from ctypes import *
import ctypes
import platform
import os
import copy

################################################################################
from mba.versions import MBA_PYTHON_VERSION as __version__

################################################################################
TYPE_MBA = 0
TYPE_CAN = 1
_name_type = ["MBA", "CAN"]

E_OK    =  0
E_ERR   = -1
E_INIT  = -2
E_ARG   = -3
E_NODEV = -4

CAN0 = 0
CAN1 = 1

CAN_MSG_RX  = 0
CAN_MSG_TX  = 1
CAN_MSG_ERR = 2
CAN_MSG_DBG = 3
CAN_MSG_BITRATE = 4
CAN_MSG_MODE = 5
_name_can_msg = ["RX", "TX", "ERR", "DBG", "BITRATE", "MODE"]

CAN_MODE_CLASSIC = 0
CAN_MODE_FDNISO  = 1
CAN_MODE_FD      = 2

CAN_TESTMODE_INIT        = 0
CAN_TESTMODE_NORMAL      = 1
CAN_TESTMODE_LISTEN      = 2
CAN_TESTMODE_LOOPBACK    = 3
CAN_TESTMODE_EXTLOOPBACK = 4

CANFRAME_FLAG_NONE      = 0x0
CANFRAME_FLAG_EXTENDED  = 0x1
CANFRAME_FLAG_FD        = 0x2
CANFRAME_FLAG_BRS       = 0x4

MBA_CMD_TIMESTAMP = 1
MBA_CMD_VERSION = 2
MBA_CMD_USBERROR = 3
MBA_CMD_DEVICEDISCONNECTED = 4
MBA_CMD_DEVICERECONNECTED = 5
_name_mba_cmd = ["RESERVED", "TIMESTAMP", "VERSION", "USBERROR", "DISCONNECT", "RECONNECT"]

MBA_RESET_APPLICATION = 0
MBA_RESET_BOOTLOADER = 1

CAN_NOMINAL_SPEEDS = [125, 250, 500, 1000]
CAN_DATA_SPEEDS = [1000, 2000, 3077, 4000, 5000, 6667, 8000]

g_callback = collections.defaultdict(dict)


################################################################################
def convert_timestamp(timestamp):
    """Convert a timestamp to sec, msec, usec

    :param timestamp: Timestamp
    :return: sec, msec, usec as ints
    """
    usec: int = timestamp % 1000
    msec: int = (timestamp // 1000) % 1000
    sec: int = timestamp // 1000000
    return sec, msec, usec


################################################################################
class MessageStructure(Structure):
    """Message structure class. Providesa parent Structure class with extra
    helper functions.

    """
    _pack_ = 1
    _fields_ = []

    def __init__(self):
        """Standard object init function.

        """
        super(MessageStructure, self).__init__()
        logging.debug('MessageStructure __init__')

        # This doesn't get called?!!!!!!!!!!!!!!!!!

    def get_string(self, prepend=''):
        """Get a printable string representation of the object attributes.

        :param prepend: String to prepend to each line
        :return: printable string
        """
        # move this calculation to __init__
        self._max_field_name_len = 0
        for field in self._fields_:
            if len(field[0]) > self._max_field_name_len:
                self._max_field_name_len = len(field[0])

        s = prepend + '%s = \n' % str(self.__class__.__name__)
        end_check = len(self._fields_) - 1
        for count, field in enumerate(self._fields_):
            name = '{:{align}{width}}'.format(field[0], align='', width='%s'%str(self._max_field_name_len))
            if 'timestamp' == field[0]:
                ts = convert_timestamp(getattr(self, field[0]))
                value = f"{ts[0]}:{ts[1]:03}.{ts[2]:03}"
            elif 'data' == field[0]:
                length = getattr(self, 'dlc')
                byte_array = getattr(self, field[0])
                value = '%s byte(s) hex = ' % str(length)
                byte_end_check = length - 1
                for byte_count, data in enumerate(byte_array[:length]):
                    value += '{:02X}'.format(data)
                    if byte_count < byte_end_check:
                        value += '.'
            else:
                value = str(getattr(self, field[0]))
            s += prepend + '    %s = %s' % (name, value)
            if count < end_check:
                s += '\n'

        return s


################################################################################
class AbaDevice(MessageStructure):
    """ABA Device messsage structure.

    """
    _pack_ = 1
    _fields_ = [
        ("deviceType", c_ulong),
        ("serial", (c_char * 40))
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(AbaDevice, self).__init__()


################################################################################
class AbaMessage(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("instance", c_ubyte),
        ("messageType", c_ubyte),
        ("command", c_ubyte),
        ("reserved", c_ubyte),
        ("data", c_void_p),
        ("data_length", c_ulong)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(AbaMessage, self).__init__()


################################################################################
class CanBitrate(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("busId", c_ulong),
        ("nsjw", c_ubyte),
        ("nseg1", c_ubyte),
        ("nseg2", c_ubyte),
        ("nscale", c_ubyte),
        ("dsjw", c_ubyte),
        ("dseg1", c_ubyte),
        ("dseg2", c_ubyte),
        ("dscale", c_ubyte),
        ("tdc", c_ubyte),
        ("tdcf", c_ubyte),
        ("tdco", c_ubyte)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(CanBitrate, self).__init__()


################################################################################
class CanDbg(MessageStructure):
    _pack_ = 1
    _fields_ = [
        ("addr", c_ulong),
        ("value", c_ubyte)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(CanDbg, self).__init__()


################################################################################
class CanError(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("busId", c_ulong),
        ("busOff", c_ubyte),
        ("tec", c_ubyte),
        ("rec", c_ubyte),
        ("lec", c_ubyte),
        ("dlec", c_ubyte),
        ("timestamp", c_ulonglong)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(CanError, self).__init__()


################################################################################
class CanFrame(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("busId", c_ulong),
        ("id", c_ulong),
        ("timestamp", c_ulonglong),
        ("dlc", c_ubyte),
        ("flags", c_ubyte),
        ("data", (c_ubyte * 64))
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(CanFrame, self).__init__()


################################################################################
class CanMode(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("busId", c_ulong),
        ("mode", c_ubyte),
        ("testMode", c_ubyte),
        ("retryEnabled", c_ubyte)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(CanMode, self).__init__()


################################################################################
class MbaDeviceDisconnected(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = []

    def __init__(self):
        """Standard object init function.

        """
        super(MbaDeviceDisconnected, self).__init__()
        logging.debug('MbaDeviceDisconnected __init__')


################################################################################
class MbaDeviceReconnected(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = []

    def __init__(self):
        """Standard object init function.

        """
        super(MbaDeviceReconnected, self).__init__()
        logging.debug('MbaDeviceReconnected __init__')


################################################################################
class MbaTimestamp(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("hash", c_uint32),
        ("api", c_uint32),
        ("firmware", c_uint32),
        ("bootloader", c_uint32),
        ("hardware", c_uint32)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(MbaTimestamp, self).__init__()
        logging.debug('MbaTimestamp __init__')


################################################################################
class MbaUsbError(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = []

    def __init__(self):
        """Standard object init function.

        """
        super(MbaDeviceReconnected, self).__init__()
        logging.debug('MbaUsbError __init__')


################################################################################
class MbaVersion(MessageStructure):
    """

    """
    _pack_ = 1
    _fields_ = [
        ("hash", c_uint32),
        ("api", c_uint32),
        ("firmware", c_uint32),
        ("bootloader", c_uint32),
        ("hardware", c_uint32)
    ]

    def __init__(self):
        """Standard object init function.

        """
        super(MbaVersion, self).__init__()
        logging.debug('MbaVersion __init__')


################################################################################
MESSAGE_CLASSES = [AbaDevice,
                   AbaMessage,
                   CanBitrate,
                   CanDbg, CanFrame,
                   CanError, CanMode,
                   MbaDeviceDisconnected,
                   MbaDeviceReconnected,
                   MbaTimestamp,
                   MbaUsbError,
                   MbaVersion]


################################################################################
class MbaCallbackData(object):
    """MBA Callback Data object.
    """
    def __init__(self, *args, **kwargs):
        """Standard object init function. All kwargs are converted to attributes of this object.
        """
        super(MbaCallbackData, self).__init__()
        if len(args):
            raise Exception("Must use key word arguments.")

        self.kwargs = kwargs

        self._max_kwarg_key_length = 0
        for k, v in kwargs.items():
            if len(k) > self._max_kwarg_key_length:
                self._max_kwarg_key_length = len(k)
            setattr(self, k, v)

    def get_string(self, prepend=''):
        """Get a printable string representation of the object attributes.

        :param prepend: String to prepend to each line
        :return: printable string
        """
        s = prepend + '%s = \n' % str(self.__class__.__name__)
        end_check = len(self.kwargs) - 1
        count = 0
        for k, v in self.kwargs.items():
            name = '{:{align}{width}}'.format(k, align='', width='%s'%str(self._max_kwarg_key_length))
            if 'msg' == k:
                attr = getattr(self, k)
                s += attr.get_string(prepend='    ')
            else:
                value = str(getattr(self, k))
                s += prepend + '    %s = %s' % (name, value)
            if count < end_check:
                s += '\n'
            count += 1

        return s


################################################################################
def _load_driver():
    """Load the MBA driver.

    :return: CDLL instance for the driver.
    """
    logging.debug('Loading driver')
    platform_system = platform.system()
    if "Windows" == platform_system:
        dll_paths = [
            ('MbaInterface.dll', 0, ''),
            ('MbaInterface.dll', 1, ''),
            ('MbaInterface.dll', 4, 'Debug'),
            ('AbaInterface.dll', 4, 'Debug')]
    elif "Linux" == platform_system:
        dll_paths = [
            ('AbaInterface', 0, ''),
            ('AbaInterface', 1, ''),
            ('AbaInterface', 4, 'Debug')]
    else:
        raise Exception("Invalid platform.system() = %s. Must be Windows or Linux." % platform_system)

    this_dir = os.path.dirname(os.path.abspath(__file__))
    logging.debug('cwd = %s' % str(this_dir))

    dll_file = None
    for dll_path in dll_paths:
        dll_dir = this_dir
        for i in range(dll_path[1]):
            try:
                dll_dir = os.path.dirname(dll_dir)
            except:
                pass
        dll_dir = os.path.join(dll_dir, dll_path[2])
        full_path = os.path.join(dll_dir, dll_path[0])
        logging.debug('Looking for %s' % str(full_path))
        if os.path.isfile(full_path):
            dll_file = dll_path[0]
            break
    if dll_file is None:
        raise Exception('Failed to find driver file.')

    logging.debug('Driver found. Loading from %s.' % str(full_path))
    logging.debug('dll_file = %s' % str(dll_file))
    logging.debug('dll_dir = %s' % str(dll_dir))

    old_cwd = os.getcwd()
    os.chdir(dll_dir)
    logging.debug('new cwd = %s' % str(os.getcwd()))
    try:
        driver = CDLL(dll_file)
    except FileNotFoundError:
        logging.exception('Failed CDLL.')
        driver = None

    logging.debug('Back to original cwd.')
    os.chdir(old_cwd)

    if driver is not None:
        logging.debug('Driver loaded.')

    return driver


################################################################################
def _mba_callback(message, user_data):
    """ Callback dispatcher
    Do not call directly!!!
    """
    _msg = ctypes.cast(message, POINTER(AbaMessage))
    msg: AbaMessage = _msg[0]

    """
    MBA interface specifies a single callback. The message provided to the callback contains the device instance and channel number.
    A dictionary maps the callbacks of the individual python MBA objects to the according device instance number.
    """
    global g_callback
    cb = g_callback.get(msg.instance)
    if cb is not None:
        cb_func = cb['callback']
        user_data = cb['user_data']
        if TYPE_CAN == msg.messageType:
            logging.debug('_mba_callback msg.messageType = %s (%s), msg.command = %s (%s)' % \
                ( _name_type[msg.messageType], str(msg.messageType), _name_can_msg[msg.command], str(msg.command) ) )
            if CAN_MSG_BITRATE == msg.command:
                _can_bitrate: CanBitrate = ctypes.cast(msg.data, POINTER(CanBitrate))
                can_bitrate: CanBitrate = copy.deepcopy(_can_bitrate[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=can_bitrate,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif CAN_MSG_DBG == msg.command:
                _can_debug: CanDbg = ctypes.cast(msg.data, POINTER(CanDbg))
                can_debug: CanDbg = copy.deepcopy(_can_debug[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=can_debug,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif CAN_MSG_ERR == msg.command:
                _can_err: CanError = ctypes.cast(msg.data, POINTER(CanError))
                can_err: CanError = copy.deepcopy(_can_err[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=can_err,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif CAN_MSG_MODE == msg.command:
                _can_mode: CanMode = ctypes.cast(msg.data, POINTER(CanMode))
                can_mode: CanMode = copy.deepcopy(_can_mode[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=can_mode,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif CAN_MSG_RX == msg.command or CAN_MSG_TX == msg.command:
                _can_msg: CanFrame = ctypes.cast(msg.data, POINTER(CanFrame))
                can_msg: CanFrame = copy.deepcopy(_can_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=can_msg,
                                       user_data=user_data,
                                       dir=msg.command,
                                       instance=msg.instance)
                cb_func(data)
            else:
                logging.debug('_mba_callback unsupported CAN command received: %s' % str(msg.command))
        elif TYPE_MBA == msg.messageType:
            logging.debug('_mba_callback msg.messageType = %s (%s), msg.command = %s (%s)' % \
                ( _name_type[msg.messageType], str(msg.messageType), _name_mba_cmd[msg.command], str(msg.command) ) )
            if MBA_CMD_DEVICEDISCONNECTED == msg.command:
                _version_msg: MbaVersion = ctypes.cast(msg.data, POINTER(MbaDeviceDisconnected))
                version_msg: MbaVersion = copy.deepcopy(_version_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=version_msg,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif MBA_CMD_DEVICERECONNECTED == msg.command:
                _version_msg: MbaVersion = ctypes.cast(msg.data, POINTER(MbaDeviceReconnected))
                version_msg: MbaVersion = copy.deepcopy(_version_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=version_msg,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif MBA_CMD_TIMESTAMP == msg.command:
                _version_msg: MbaVersion = ctypes.cast(msg.data, POINTER(MbaTimestamp))
                version_msg: MbaVersion = copy.deepcopy(_version_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=version_msg,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif MBA_CMD_USBERROR == msg.command:
                _version_msg: MbaVersion = ctypes.cast(msg.data, POINTER(MbaUsbError))
                version_msg: MbaVersion = copy.deepcopy(_version_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=version_msg,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            elif MBA_CMD_VERSION == msg.command:
                _version_msg: MbaVersion = ctypes.cast(msg.data, POINTER(MbaVersion))
                version_msg: MbaVersion = copy.deepcopy(_version_msg[0])
                data = MbaCallbackData(type=msg.messageType,
                                       command=msg.command,
                                       msg=version_msg,
                                       user_data=user_data,
                                       instance=msg.instance)
                cb_func(data)
            else:
                logging.debug('_mba_callback unsupported MBA command received: %s' % str(msg.command))
        else:
            logging.debug("_mba_callback unsupported message type received: %s" + str(msg.messageType))
            pass


################################################################################
def enum_devices():
    """ Enumerate connected Microchip Bus Analyzer (ABA, CBA) devices

    :return: Returns a tuple (Number of devices, [List of device types], [List of serial numbers])
    """
    driver = _load_driver()
    if driver is None:
        return 0, [], []
    ctr = 0
    device_type = []
    device_list = []
    devices = POINTER(AbaDevice)()
    count = driver.enumDevices(byref(devices))
    logging.debug("Found " + str(count) + " MBA devices")
    while count > ctr:
        serial_string = devices[ctr].serial.decode("utf-8")
        logging.debug("    Serial: " + serial_string)
        device_list.append(serial_string)
        device_type.append(devices[ctr].deviceType)
        ctr += 1
    return count, device_type, device_list


################################################################################
class Mba:
    """
    MBA Interface Object

    Usage:
        >>> import mba
        >>> num_devices, device_types, device_serial_nums = mba.enum_devices()
        >>> device = Mba()
        >>> instance = device.open_device(serial_num=device_serial_nums[0])
        >>> device.can_reset(mba.CAN0)
        >>> device.can_set_speed(...)
        >>> device.can_set_mode(...)
        >>> device.can_send_frame(...)
        >>> device.close_device()
    """
    _cb_func = CFUNCTYPE(None, c_void_p, c_void_p)
    _m_cb_func = _cb_func(_mba_callback)

    def __init__(self):
        """Standard object init function.

        """
        super(Mba, self).__init__()
        self._driver = None
        self._aba_handle = None
        self.instance_id = -1

        self._driver = _load_driver()

    def __del__(self):
        """

        :return:
        """
        if self._aba_handle is not None:
            try:
                self.close_device()
            except:
                pass
        if self._driver is not None:
            try:
                self._driver.unload()
            except:
                pass

    def can_reset(self, bus_id):
        """ Reset the CAN bus to initial values
        Removes the device from the CAN bus so it will not participate in communication anymore
        :return: 0 on success or a negative number on failure
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.CAN_Reset(self._aba_handle, bus_id)
        except Exception as exc:
            logging.exception('Failed can_reset')
        return E_ERR

    def can_send_frame(self, bus_id, can_id, payload, dlc, flags, timeout):
        """ Send a CAN(FD) frame
        :param bus_id: CAN0 or CAN1
        :param can_id: ?
        :param payload: A python byte array
        :param dlc: Number of bytes to be sent
        :param flags: [CANFRAME_FLAG_NONE, CANFRAME_FLAG_EXTENDED, CANFRAME_FLAG_FD, CANFRAME_FLAG_BRS]
        :param timeout: Timeout in seconds
        :return: 0 on success or a negative number on failure
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                array_type = c_ubyte * dlc
                _payload = array_type(*(payload[:dlc]))
                return self._driver.CAN_SendFrame(
                    self._aba_handle, bus_id, can_id, byref(_payload), dlc, flags, timeout)
        except Exception as exc:
            logging.exception('Failed can_send_frame')
        return E_ERR

    def can_set_mode(self, bus_id, mode, test_mode, auto_retry):
        """ Set the operation mode of a CAN bus
        :param bus_id: CAN0 or CAN1
        :param mode: CAN operation mode from preset [CAN_MODE_CLASSIC, CAN_MODE_FDNISO, CAN_MODE_FD]
        :param test_mode: CAN test mode from preset [CAN_TESTMODE_NORMAL, CAN_TESTMODE_LISTEN, CAN_TESTMODE_LOOPBACK, CAN_TESTMODE_EXTLOOPBACK]
        :param auto_retry: Enable HW based retransmission if transmission has failed
        :return: 0 on success or a negative number on failure
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.CAN_SetMode(self._aba_handle, bus_id, mode, test_mode, auto_retry)
        except Exception as exc:
            logging.exception('Failed can_set_mode.')
        return E_ERR

    def can_set_speed(self, bus_id, nominal_speed, data_speed):
        """ Set the speed of a CAN bus
        :param bus_id: CAN0 or CAN1
        :param nominal_speed: Classic CAN speed from preset values [125, 250, 500, 1000]
        :param data_speed: CAN-FD speed from preset values [1000, 2000, 3077, 4000, 5000, 6667, 8000]
        :return: 0 on success or a negative number on failure
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.CAN_SetSpeed(self._aba_handle, bus_id, nominal_speed, data_speed)
        except Exception as exc:
            logging.exception('Failed can_set_speed.')
        return E_ERR

    def close_device(self):
        """ Close a device that has been opened with open_device(...)
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                logging.debug("Closing MBA device: " + str(self._aba_handle))
                global g_callback
                g_callback.clear()
                self._driver.unregisterCallback()
                self._driver.closeDevice(self._aba_handle)
                logging.debug("MBA device closed!")
                self._aba_handle = None
            else:
                logging.warning("closeDevice was called, but device was not open/already closed")
        except Exception as exc:
            logging.exception('Failed close_device.')

    def open_device(self, serial_num):
        """ Open a Microchip Bus Analyzer (_driver, CBA) device

        The instance id returned by openDevice is fixed to the order of devices being opened.
        If a device is closed and reopened, it will be assigned the same instance id again, even
        if other devices have been opened in the meantime.

        :param serial_num: A string representing the serialnumber of the MBA device
        :return: A negative number on error or the instance id of the device
        """
        exc = None
        try:
            serial_string = str(serial_num)
            if self._driver is not None and self._aba_handle is None:
                logging.debug("trying to open device with serial: " + serial_string)
                self._aba_handle = c_void_p()
                buf = c_char_p(serial_string.encode("utf-8"))
                self.instance_id = self._driver.openDevice(byref(self._aba_handle), buf)
                if self.instance_id < 0:
                    logging.error("Failed to open device sn=%s" % str(serial_num))
                    self._aba_handle = None
                return self.instance_id
        except Exception as exc:
            logging.exception('Failed open_device.')
        return E_ERR

    def mba_reset(self, reset_mode):
        """Reset the MBA
        :param reset_mode: Reset mode [MBA_RESET_APPLICATION, MBA_RESET_BOOTLOADER]
        :result: E_OK on success
        :result: E_ARG if mba_device is invalid
        :result: E_ERR if USB communication failed
        """
        exc = None
        try:
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.MBA_Reset(self._aba_handle, reset_mode)
        except Exception as exc:
            logging.exception('Failed mba_reset.')
        return E_ERR

    def mba_twinkle(self):
        """Blink LED
        :result E_OK on success
        :result E_ARG if mba_device is invalid
        :result E_ERR if USB communication failed
        """
        exc = None
        try:
            logging.debug('Sending MBA_Twinkle.')
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.MBA_Twinkle(self._aba_handle)
        except Exception as exc:
            logging.exception('Failed mba_twinkle.')
        return E_ERR

    def mba_get_version(self):
        """Query the MBA firmware version
        :result E_OK on success
        :result E_ARG if mba_device is invalid
        :result E_ERR if USB communication failed
        """
        exc = None
        try:
            logging.debug('Sending MBA_GetVersion.')
            if self._aba_handle is not None and self._aba_handle != c_void_p(None):
                return self._driver.MBA_GetVersion(self._aba_handle)
        except Exception as exc:
            logging.exception('Failed mba_get_version.')
        return E_ERR

    def register_callback(self, callback, user_data):
        """ Register a user callback

        :param callback: A callback function that specifies following parameters: def callback(data):
        :param user_data: Optional userData which will be provided to the callback
        :return: 0 on success or a negative number on failure
        """
        global g_callback
        exc = None
        try:
            if self._driver is not None or self.instance_id < 0:
                logging.debug("Instance=%s registering MBA callback." + str(self.instance_id))
                g_callback[self.instance_id] = {'callback': callback, 'user_data': user_data}
                self._driver.registerCallback(self._m_cb_func, 0)
                return E_OK
        except Exception as exc:
            logging.exception('Failed register_callback')
        return E_ERR

